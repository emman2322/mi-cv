const express = require("express");
const path = require('path');
const mysql = require("mysql");
const dotenv = require('dotenv');
const bcrypt = require('bcrypt');
const os = require('os'); //modulo para obtener la ip

dotenv.config({ path: './.env' });

const app = express();
const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE
});

// Middleware para manejar datos de formularios
app.use(express.urlencoded({ extended: false }));

// Servir archivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

// Configuración de vistas
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hbs');

db.connect((error) => {
    if (error) {
        console.error("Error al conectar a MySQL:", error);
    } else {
        console.log("MySQL conectado...");
    }
});

//pa obtener la direccion ip del servidor 
const getLocalIP = () =>{
    const interfaces  = os.networkInterfaces();
    for(let interfaceName in interfaces){
        for(let iface of interfaces[interfaceName]){
            if(iface.family === 'IPv4' && !iface.internal){
                return iface.address; //iplocal
            }
        }
    }
    return 'no pos no se encontro la IP chavo';
}

// Ruta principal que renderiza la vista 'login.hbs'
app.get("/", (req, res) => {
    res.render("login", { error: null }); 
});

// Ruta para el registro
app.post("/register", async (req, res) => {
    const { name, email, user, password } = req.body; 
    const hashedPassword = await bcrypt.hash(password, 10); // Hashea la contraseña

    const query = "INSERT INTO users (name, email, user, password) VALUES (?, ?, ?, ?)";
    db.query(query, [name, email, user, hashedPassword], (error, results) => {
        if (error) {
            console.error("Error al registrar:", error.message);
            return res.status(500).send("Error en el registro");
        }
        res.send("Registro exitoso");
    });
});

// Ruta para el login
app.post("/login", async (req, res) => {
    const { email, password } = req.body; 
    const trimmedEmail = email.trim(); // Elimina espacios en blanco
    const trimmedPassword = password.trim(); // Elimina espacios en blanco
    const query = "SELECT * FROM users WHERE email = ?";

    db.query(query, [trimmedEmail], async (error, results) => {
        if (error) {
            console.error("Error en el inicio de sesión:", error);
            return res.status(500).send("Error en el inicio de sesión");
        }
        if (results.length > 0) {
            const user = results[0];
            const match = await bcrypt.compare(trimmedPassword, user.password); 
            console.log("Contraseña coincide:", match); // Para depuración
            if (match) {
                const ip = getLocalIP(); //obtiene la ip local
                res.render("lobby",{ user: user.user, ip: ip}); // Redirige al lobby si las credenciales son correctas
            } else {
                return res.render("login", { error: "Credenciales incorrectas" });
            }
        } else {
            return res.render("login", { error: "Credenciales incorrectas" });
        }
    });
});

// Ruta para cerrar sesión
app.get("/logout", (req, res) => {
    // Aquí puedes manejar el cierre de sesión, como eliminar la sesión del usuario
    res.redirect("/"); // Redirige al login después de cerrar sesión
});

app.listen(5001, () => {
    console.log("Servidor iniciado en el puerto 5001");
});
